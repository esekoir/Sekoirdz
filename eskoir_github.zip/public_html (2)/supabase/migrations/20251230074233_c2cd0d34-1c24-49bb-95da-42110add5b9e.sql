-- Add wilaya column to profiles table
ALTER TABLE public.profiles ADD COLUMN wilaya TEXT;